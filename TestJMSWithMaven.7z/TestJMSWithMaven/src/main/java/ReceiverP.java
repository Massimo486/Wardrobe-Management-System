import javax.jms.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import java.util.Hashtable;

public class ReceiverP {

    public static void main(String[] args) throws NamingException, JMSException {

        Hashtable<String, String> props = new Hashtable<String, String>();
        props.put(Context.INITIAL_CONTEXT_FACTORY, "org.apache.activemq.jndi.ActiveMQInitialContextFactory");
        props.put(Context.PROVIDER_URL, "tcp://localhost:61616");

        Context context = new InitialContext(props);

        QueueConnectionFactory connFactory = (QueueConnectionFactory) context.lookup("ConnectionFactory");

        QueueConnection conn = connFactory.createQueueConnection();
        QueueSession session = conn.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
        Queue q = (Queue) context.lookup("dynamicQueues/testQueue");

        QueueReceiver receiver = session.createReceiver(q);
        conn.start();
        Message m = receiver.receive();

        if(m instanceof TextMessage) {
            TextMessage txt = (TextMessage) m;
            System.out.println("Message received: " + txt.getText());
        }

        session.close();
        conn.close();
    }
}
